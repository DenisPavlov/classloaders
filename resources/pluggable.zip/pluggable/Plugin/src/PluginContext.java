import javax.swing.JButton;
import javax.swing.JFrame;


public interface PluginContext {
	public JButton getButton();
	public JFrame getFrame();
}
